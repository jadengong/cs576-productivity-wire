#include "actions.h"

#include <stdatomic.h>
#include <time.h>

#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "reporter.h"

static const char *TAG = "actions";

typedef struct {
    time_t timestamp;
    unsigned int session;
} trigger_t;

static QueueHandle_t trigger_queue;
/* Odd sessions are armed; changing sessions invalidates queued old triggers. */
static atomic_uint current_session;

static void reporting_task(void *argument)
{
    (void)argument;
    trigger_t trigger;
    for (;;) {
        if (xQueueReceive(trigger_queue, &trigger, portMAX_DELAY) != pdTRUE) {
            continue;
        }
        if (trigger.session != atomic_load(&current_session)) {
            continue;
        }
        esp_err_t err = reporter_send_trigger(trigger.timestamp);
        if (err != ESP_OK) {
            ESP_LOGW(TAG, "Trigger not confirmed: %s", esp_err_to_name(err));
            /* No automatic retries: the API has no deduplication, and a timeout
             * may happen after the host already received a workspace command. */
        }
    }
}

esp_err_t actions_init(void)
{
    if (trigger_queue != NULL) {
        return ESP_OK;
    }
    trigger_queue = xQueueCreate(8, sizeof(trigger_t));
    if (trigger_queue == NULL) {
        return ESP_ERR_NO_MEM;
    }
    if (xTaskCreate(reporting_task, "trigger_reporter", 8192, NULL, 5, NULL) != pdPASS) {
        vQueueDelete(trigger_queue);
        trigger_queue = NULL;
        return ESP_ERR_NO_MEM;
    }
    return ESP_OK;
}

bool actions_is_running(void)
{
    return (atomic_load(&current_session) & 1U) != 0;
}

esp_err_t actions_start(void)
{
    if (trigger_queue == NULL) {
        return ESP_ERR_INVALID_STATE;
    }
    unsigned int session = atomic_load(&current_session);
    if ((session & 1U) != 0) {
        return ESP_OK;
    }
    esp_err_t err = reporter_prepare();
    if (err != ESP_OK) {
        return err;
    }
    if (!atomic_compare_exchange_strong(&current_session, &session, session + 1)) {
        return ESP_ERR_INVALID_STATE;
    }

    /* Add the device's start behavior here. */
    /* Basically either start the IR break beam, or change it's output style from trashing to collecting */
    ESP_LOGI(TAG, "Started: beam-break reporting armed");
    return ESP_OK;
}

esp_err_t actions_stop(void)
{
    unsigned int session = atomic_load(&current_session);
    while ((session & 1U) != 0 &&
           !atomic_compare_exchange_weak(&current_session, &session, session + 1)) {
    }
    /* Add the device's stop behavior here. */
    /* Stop the IR break beam, alternatively send it's data to trash */
    /* Pending old-session triggers are discarded. An HTTP request already in
     * flight may still complete after stop. */
    ESP_LOGI(TAG, "Stopped: beam-break reporting disarmed");
    return ESP_OK;
}

esp_err_t actions_trigger(void)
{
    unsigned int session = atomic_load(&current_session);
    if (trigger_queue == NULL || (session & 1U) == 0) {
        return ESP_ERR_INVALID_STATE;
    }
    trigger_t trigger = {.timestamp = time(NULL), .session = session};
    return xQueueSend(trigger_queue, &trigger, 0) == pdTRUE ? ESP_OK : ESP_ERR_TIMEOUT;
}
