#include "network.h"
#include "actions.h"

#include "sdkconfig.h"
#include "esp_err.h"
#include "esp_event.h"
#include "esp_http_server.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_wifi.h"
#include "nvs_flash.h"

_Static_assert(sizeof(CONFIG_NETSERVER_WIFI_SSID) > 1 &&
               sizeof(CONFIG_NETSERVER_WIFI_SSID) <= 33,
               "Wi-Fi SSID must contain 1 to 32 bytes");
_Static_assert(sizeof(CONFIG_NETSERVER_WIFI_PASSWORD) == 1 ||
               (sizeof(CONFIG_NETSERVER_WIFI_PASSWORD) >= 9 &&
                sizeof(CONFIG_NETSERVER_WIFI_PASSWORD) <= 64),
               "Wi-Fi password must be empty or contain 8 to 63 bytes");

static const char *TAG = "network";

extern const char index_html_start[] asm("_binary_index_html_start");
extern const char index_html_end[] asm("_binary_index_html_end");

static esp_err_t index_get_handler(httpd_req_t *request)
{
    esp_err_t err = httpd_resp_set_type(request, "text/html; charset=utf-8");
    if (err != ESP_OK) {
        return err;
    }

    /* EMBED_TXTFILES appends a null terminator; omit it from the response. */
    return httpd_resp_send(request, index_html_start,
                           index_html_end - index_html_start - 1);
}

// Add code here later to start IR beam data reading
static esp_err_t start_post_handler(httpd_req_t *request)
{
    if (actions_start() != ESP_OK) {
        return httpd_resp_send_err(request, HTTPD_500_INTERNAL_SERVER_ERROR,
                                   "Could not start. Check the server URL, connection, and device logs.");
    }

    return httpd_resp_send(request, NULL, 0);
}

// Add code here to stop the IR beam, or just send it's data to /dev/null equivalent
static esp_err_t stop_post_handler(httpd_req_t *request)
{
    if (actions_stop() != ESP_OK) {
        return httpd_resp_send_err(request, HTTPD_500_INTERNAL_SERVER_ERROR,
                                   "Could not stop");
    }

    return httpd_resp_send(request, NULL, 0);
}

static esp_err_t state_get_handler(httpd_req_t *request)
{
    esp_err_t err = httpd_resp_set_type(request, "application/json");
    if (err != ESP_OK) {
        return err;
    }
    return httpd_resp_sendstr(request, actions_is_running()
                                      ? "{\"running\":true}" : "{\"running\":false}");
}

static esp_err_t trigger_post_handler(httpd_req_t *request)
{
    esp_err_t err = actions_trigger();
    if (err != ESP_OK) {
        httpd_resp_set_status(request, err == ESP_ERR_INVALID_STATE
                                          ? "409 Conflict" : "503 Service Unavailable");
        return httpd_resp_sendstr(request, err == ESP_ERR_INVALID_STATE
                                              ? "Press start before reporting a trigger."
                                              : "Trigger queue is full. Try again later.");
    }
    httpd_resp_set_status(request, "202 Accepted");
    httpd_resp_set_type(request, "application/json");
    return httpd_resp_sendstr(request, "{\"status\":\"queued\"}");
}

static void start_webserver(void)
{
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.stack_size = 8192;
    httpd_handle_t server = NULL;
    ESP_ERROR_CHECK(httpd_start(&server, &config));

    const httpd_uri_t root = {
        .uri = "/",
        .method = HTTP_GET,
        .handler = index_get_handler,
    };
    const httpd_uri_t index = {
        .uri = "/index.html",
        .method = HTTP_GET,
        .handler = index_get_handler,
    };
    const httpd_uri_t start = {
        .uri = "/start",
        .method = HTTP_POST,
        .handler = start_post_handler,
    };
    const httpd_uri_t stop = {
        .uri = "/stop",
        .method = HTTP_POST,
        .handler = stop_post_handler,
    };
    const httpd_uri_t state = {
        .uri = "/state",
        .method = HTTP_GET,
        .handler = state_get_handler,
    };
    const httpd_uri_t trigger = {
        .uri = "/trigger",
        .method = HTTP_POST,
        .handler = trigger_post_handler,
    };
    ESP_ERROR_CHECK(httpd_register_uri_handler(server, &root));
    ESP_ERROR_CHECK(httpd_register_uri_handler(server, &index));
    ESP_ERROR_CHECK(httpd_register_uri_handler(server, &start));
    ESP_ERROR_CHECK(httpd_register_uri_handler(server, &stop));
    ESP_ERROR_CHECK(httpd_register_uri_handler(server, &state));
    ESP_ERROR_CHECK(httpd_register_uri_handler(server, &trigger));
}

void network_start(void)
{
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        err = nvs_flash_init();
    }
    ESP_ERROR_CHECK(err);

    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_t *access_point = esp_netif_create_default_wifi_ap();

    wifi_init_config_t init_config = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&init_config));

    wifi_config_t wifi_config = {
        .ap = {
            .ssid = CONFIG_NETSERVER_WIFI_SSID,
            .ssid_len = sizeof(CONFIG_NETSERVER_WIFI_SSID) - 1,
            .password = CONFIG_NETSERVER_WIFI_PASSWORD,
            .channel = CONFIG_NETSERVER_WIFI_CHANNEL,
            .authmode = sizeof(CONFIG_NETSERVER_WIFI_PASSWORD) == 1
                            ? WIFI_AUTH_OPEN : WIFI_AUTH_WPA2_PSK,
            .max_connection = 4,
        },
    };
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());

    start_webserver();

    esp_netif_ip_info_t ip_info;
    ESP_ERROR_CHECK(esp_netif_get_ip_info(access_point, &ip_info));
    ESP_LOGI(TAG, "Wi-Fi access point: %s", CONFIG_NETSERVER_WIFI_SSID);
    ESP_LOGI(TAG, "Static web server: http://" IPSTR "/", IP2STR(&ip_info.ip));
}
