#pragma once

/* Call once at startup to create the Wi-Fi access point and static web server. */
void network_start(void);
