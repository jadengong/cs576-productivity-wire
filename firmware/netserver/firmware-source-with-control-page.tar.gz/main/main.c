#include "network.h"
#include "actions.h"

void app_main(void)
{
    ESP_ERROR_CHECK(actions_init());
    network_start();
}
