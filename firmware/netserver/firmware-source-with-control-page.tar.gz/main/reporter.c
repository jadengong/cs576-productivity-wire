#include "reporter.h"

#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <sys/time.h>

#include "sdkconfig.h"
#include "esp_http_client.h"
#include "esp_log.h"
#if CONFIG_MBEDTLS_CERTIFICATE_BUNDLE
#include "esp_crt_bundle.h"
#endif

_Static_assert(sizeof(CONFIG_NETSERVER_SERVER_URL) <= 257,
               "Server base URL must contain at most 256 bytes");
_Static_assert(sizeof(CONFIG_NETSERVER_DEVICE_ID) > 1 &&
               sizeof(CONFIG_NETSERVER_DEVICE_ID) <= 101,
               "Device ID must contain 1 to 100 bytes");

static const char *TAG = "reporter";

typedef struct {
    char body[384];
    size_t used;
    char date[64];
} server_response_t;

static esp_err_t response_handler(esp_http_client_event_t *event)
{
    server_response_t *response = event->user_data;
    if (event->event_id == HTTP_EVENT_ON_HEADER &&
        strcasecmp(event->header_key, "Date") == 0) {
        snprintf(response->date, sizeof(response->date), "%s", event->header_value);
    } else if (event->event_id == HTTP_EVENT_ON_DATA && event->data_len > 0) {
        size_t count = event->data_len;
        size_t available = sizeof(response->body) - response->used - 1;
        if (count > available) {
            count = available;
        }
        memcpy(response->body + response->used, event->data, count);
        response->used += count;
        response->body[response->used] = '\0';
    }
    return ESP_OK;
}

static esp_err_t request_server(const char *path, const char *payload,
                                int expected_status, server_response_t *response)
{
    const char *base = CONFIG_NETSERVER_SERVER_URL;
    if (strncmp(base, "http://", 7) != 0 && strncmp(base, "https://", 8) != 0) {
        ESP_LOGE(TAG, "Set the central server base URL in menuconfig");
        return ESP_ERR_INVALID_STATE;
    }

    size_t base_length = strlen(base);
    while (base_length > 0 && base[base_length - 1] == '/') {
        --base_length;
    }
    char url[288];
    int length = snprintf(url, sizeof(url), "%.*s%s", (int)base_length, base, path);
    if (length < 0 || (size_t)length >= sizeof(url)) {
        return ESP_ERR_INVALID_SIZE;
    }

    esp_http_client_config_t config = {
        .url = url,
        .method = payload ? HTTP_METHOD_POST : HTTP_METHOD_GET,
        .timeout_ms = CONFIG_NETSERVER_REQUEST_TIMEOUT_MS,
        .disable_auto_redirect = true,
        .event_handler = response_handler,
        .user_data = response,
#if CONFIG_MBEDTLS_CERTIFICATE_BUNDLE
        .crt_bundle_attach = esp_crt_bundle_attach,
#endif
    };
    esp_http_client_handle_t client = esp_http_client_init(&config);
    if (client == NULL) {
        return ESP_ERR_NO_MEM;
    }

    esp_err_t err = ESP_OK;
    if (payload != NULL) {
        err = esp_http_client_set_header(client, "Content-Type", "application/json");
        if (err == ESP_OK) {
            err = esp_http_client_set_post_field(client, payload, strlen(payload));
        }
    }
    if (err == ESP_OK) {
        err = esp_http_client_perform(client);
    }
    int status = esp_http_client_get_status_code(client);
    esp_http_client_cleanup(client);

    if (err != ESP_OK) {
        ESP_LOGE(TAG, "%s failed: %s", path, esp_err_to_name(err));
        return err;
    }
    if (status != expected_status) {
        ESP_LOGE(TAG, "%s returned HTTP %d: %s", path, status, response->body);
        return ESP_FAIL;
    }
    return ESP_OK;
}

static esp_err_t validate_device_id(void)
{
    /* Restrict IDs to ASCII identifiers so they can safely be placed in JSON. */
    for (const char *p = CONFIG_NETSERVER_DEVICE_ID; *p; ++p) {
        if (!((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
              (*p >= '0' && *p <= '9') || *p == '-' || *p == '_' || *p == '.')) {
            ESP_LOGE(TAG, "Device ID may contain only letters, digits, '.', '_' and '-'");
            return ESP_ERR_INVALID_ARG;
        }
    }
    return ESP_OK;
}

esp_err_t reporter_prepare(void)
{
    esp_err_t err = validate_device_id();
    if (err != ESP_OK) {
        return err;
    }

    server_response_t response = {0};
    err = request_server("/health", NULL, 200, &response);
    if (err != ESP_OK) {
        return err;
    }

    /* Uvicorn sends this header by default; this also works without internet/NTP. */
    struct tm utc = {0};
    char *end = strptime(response.date, "%a, %d %b %Y %H:%M:%S GMT", &utc);
    if (end == NULL || *end != '\0' || utc.tm_year < 124) {
        ESP_LOGE(TAG, "Server must return a valid HTTP Date header (enable Uvicorn date headers)");
        return ESP_ERR_INVALID_RESPONSE;
    }
    struct timeval now = {.tv_sec = timegm(&utc)};
    if (settimeofday(&now, NULL) != 0) {
        return ESP_FAIL;
    }
    ESP_LOGI(TAG, "Server reachable; clock synchronized to %s", response.date);
    return ESP_OK;
}

esp_err_t reporter_send_trigger(time_t timestamp)
{
    esp_err_t err = validate_device_id();
    if (err != ESP_OK) {
        return err;
    }
    struct tm utc;
    char formatted_time[21];
    if (gmtime_r(&timestamp, &utc) == NULL || utc.tm_year < 124 ||
        strftime(formatted_time, sizeof(formatted_time), "%Y-%m-%dT%H:%M:%SZ", &utc) == 0) {
        return ESP_ERR_INVALID_STATE;
    }

    char payload[192];
    int length = snprintf(payload, sizeof(payload),
                          "{\"device_id\":\"%s\",\"event\":\"triggered\",\"timestamp\":\"%s\"}",
                          CONFIG_NETSERVER_DEVICE_ID, formatted_time);
    if (length < 0 || (size_t)length >= sizeof(payload)) {
        return ESP_ERR_INVALID_SIZE;
    }

    server_response_t response = {0};
    err = request_server("/api/triggers", payload, 202, &response);
    if (err == ESP_OK) {
        /* Acceptance/delivery are distinct from execution on the desktop client. */
        ESP_LOGI(TAG, "Trigger accepted: %s", response.body);
    }
    return err;
}
