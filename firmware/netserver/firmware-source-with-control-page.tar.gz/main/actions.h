#pragma once

#include <stdbool.h>

#include "esp_err.h"

esp_err_t actions_init(void);

/* Start/stop arm and disarm reporting. Start also checks the server and clock. */
esp_err_t actions_start(void);
esp_err_t actions_stop(void);
bool actions_is_running(void);

/* Call on a beam break from a sensor task (not an ISR). Success means queued. */
esp_err_t actions_trigger(void);
