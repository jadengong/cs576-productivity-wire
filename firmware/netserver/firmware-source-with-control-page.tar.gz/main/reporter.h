#pragma once

#include <time.h>

#include "esp_err.h"

/* Check the server and synchronize the device clock from its HTTP Date header. */
esp_err_t reporter_prepare(void);

/* Blocking request; run from a task, never a GPIO interrupt handler. */
esp_err_t reporter_send_trigger(time_t timestamp);
